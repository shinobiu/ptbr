<?php
// Heading
$_['heading_title']    = 'Welt Karte';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Dashboard Welt Karte modifiziert!';
$_['text_edit']        = 'Berarbeite Dashboard Welt Karte';
$_['text_order']       = 'Bestellungen';
$_['text_sale']        = 'Verkäufe';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';
$_['entry_width']      = 'Breite';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Dashboard Welt Karte zu modifizieren!';
