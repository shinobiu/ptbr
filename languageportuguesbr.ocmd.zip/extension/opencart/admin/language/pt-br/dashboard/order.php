<?php
// Heading
$_['heading_title']    = 'Bestellugen Gesamt';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Dashboard Bestellugen Gesamt modifiziert!';
$_['text_edit']        = 'Bearbeite Dashboard Bestellugen Gesamt';
$_['text_view']        = 'Zeige mehr...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';
$_['entry_width']      = 'Breite';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Dashboard Bestellugen Gesamt zu modifizieren!';
