<?php
// Heading
$_['heading_title']    = 'Aktuell Online';

// Text
$_['text_extension']   = 'Erweiterugen';
$_['text_success']     = 'Erfolgreich: Sie haben Dashboard Aktuell Online modifiziert!';
$_['text_edit']        = 'Bearbeite Dashboard Aktuell Online';
$_['text_view']        = 'Zeige mehr...';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';
$_['entry_width']      = 'Breite';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Dashboard Aktuell Online zu modifizieren!';
