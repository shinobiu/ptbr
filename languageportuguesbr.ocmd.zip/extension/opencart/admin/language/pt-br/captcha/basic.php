<?php
// Heading
$_['heading_title']    = 'Basic Captcha (einfache Version)';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben das Basic Captcha modifiziert!';
$_['text_edit']        = 'Bearbeite Basic Captcha';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Basic Captcha zu modifizieren!';
