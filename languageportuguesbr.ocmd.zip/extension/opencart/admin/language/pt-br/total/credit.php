<?php
// Heading
$_['heading_title']    = 'Guthaben Status';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Guthaben Staus modifiziert!';
$_['text_edit']        = 'Bearbeite Guthaben Status';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Guthaben Status zu modifizieren!';
