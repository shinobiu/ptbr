<?php
// Heading
$_['heading_title']    = 'Gesamtbetrag';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Gesamtbetrag modifiziert!';
$_['text_edit']        = 'Bearbeite Gesamtbetrag';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Gesamtbetrag zu modifizieren!';
