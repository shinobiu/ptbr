<?php
// Heading
$_['heading_title']    = 'Geschenkgutschein';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Geschenkgutschein modifiziert!';
$_['text_edit']        = 'Bearbeite Geschenkgutschein';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Geschenkgutschein zu modifizieren!';
