<?php
// Heading
$_['heading_title']    = 'Steuer';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Steuer modifiziert!';
$_['text_edit']        = 'Bearbeite Steuer';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Steuer zu modifizieren!';
