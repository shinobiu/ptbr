<?php
// Heading
$_['heading_title']    = 'Verwendung eines Coupon-Codes (Rabatt-Gutschein)';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Verwendung eines Coupon-Codes modifiziert!';
$_['text_edit']        = 'Bearbeite Verwendung eines Coupon-Codes';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung VVerwendung eines Coupon-Codes zu modifizieren!';
