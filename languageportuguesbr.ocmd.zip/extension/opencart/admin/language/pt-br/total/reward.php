<?php
// Heading
$_['heading_title']    = 'Prämienpunkte (Reward)';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Prämienpunkte modifiziert!';
$_['text_edit']        = 'Bearbeite Prämienpunkte';

// Entry
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Prämienpunkte zu modifizieren!';
