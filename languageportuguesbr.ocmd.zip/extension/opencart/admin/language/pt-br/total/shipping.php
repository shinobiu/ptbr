<?php
// Heading
$_['heading_title']    = 'Kostenvoranschlag kalkulieren (Versand und Steuer)';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Kostenvoranschlag kalkulieren modifiziert!';
$_['text_edit']        = 'Bearbeite Kostenvoranschlag kalkulieren';

// Entry
$_['entry_estimator']  = 'Kostenvoranschlag kalkulieren';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierreihenfolge';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Kostenvoranschlag kalkulieren zu modifizieren!';
