<?php
// Heading
$_['heading_title']    = 'Kategorien';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben das Kategorien Modul modifiziert!';
$_['text_edit']        = 'Bearbeite Kategorien Modul';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung das Kategorien Modul zu modifizieren!';
