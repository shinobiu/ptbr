<?php
// Heading
$_['heading_title']    = 'Informationen';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben das Informationen Modul modifiziert!';
$_['text_edit']        = 'Bearbeite Informationen Modul';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: Sie haben keine Berechtibung das Informationen Modul zu modifizieren!';
