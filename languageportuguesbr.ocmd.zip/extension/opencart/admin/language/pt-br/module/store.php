<?php
// Heading
$_['heading_title']    = 'Online-Shops (Stores) Modul';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben das Online-Shops (Stores) Modul modifiziert!';
$_['text_edit']        = 'Online-Shops (Stores) Modul bearbeiten';

// Entry
$_['entry_admin']      = 'Nur für Administratoren';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung das Online-Shops (Stores) Modul zu modifizieren!';
