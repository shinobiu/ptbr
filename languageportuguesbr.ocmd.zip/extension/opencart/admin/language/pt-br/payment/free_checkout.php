<?php
// Heading
$_['heading_title']      = 'Kostenfreies Auschecken';

// Text
$_['text_extension']     = 'Erweiterungen';
$_['text_success']       = 'Erfolgreich: Sie haben Kostenfreies Auschecken modifiziert!';
$_['text_edit']          = 'Bearbeite Kostenfreies Auschecken';

// Entry
$_['entry_order_status'] = 'Bestell-Status';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sortierung';

// Error
$_['error_permission']   = 'Warnung: Sie haben keine Berechtigung Kostenfreies Auschecken zu modifizieren!';
