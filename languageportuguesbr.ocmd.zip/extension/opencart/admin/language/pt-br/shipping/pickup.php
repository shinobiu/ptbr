<?php
// Heading
$_['heading_title']    = 'Abholung (Pickup)';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Abholung modifiziert!';
$_['text_edit']        = 'Bearbeite Abholung';

// Entry
$_['entry_geo_zone']   = 'Geo-Zone';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sortierung';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Abholung zu modifizieren!';
