<?php
// Heading
$_['heading_title']    = 'Standard Template (Theme)';

// Text
$_['text_extension']   = 'Erweiterungen';
$_['text_success']     = 'Erfolgreich: Sie haben Standard Template modifiziert!';
$_['text_edit']        = 'Bearbeite Standard Template';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung Standard Template zu modifizieren!';
