<?php
// Heading
$_['heading_title'] = 'Em Destaque';
