<?php
// Heading
$_['heading_title'] = 'Informações';

// Text
$_['text_contact']  = 'Informações de contato';
$_['text_sitemap']  = 'Site Mapa';
