<?php
// Heading
$_['heading_title']     = 'Minha Conta';

// Text
$_['text_register']     = 'Novo Cadastro';
$_['text_login']        = 'Entrar';
$_['text_logout']       = 'Sair';
$_['text_forgotten']    = 'Esqueci a senha';
$_['text_account']      = 'Gerenciar a conta';
$_['text_edit']         = 'Editar dados da conta';
$_['text_password']     = 'Alterar senha';
$_['text_address']      = 'Gerenciar o catálogo de endereços';
$_['text_wishlist']     = 'Editar lista de desejos';
$_['text_order']        = 'Ver pedidos';
$_['text_download']     = 'Gerenciar downloads';
$_['text_reward']       = 'Exibir pontos de recompensa';
$_['text_return']       = 'Devoluções';
$_['text_transaction']  = 'Ver Pedidos';
$_['text_newsletter']   = 'Gerenciar boletins informativos';
$_['text_subscription'] = 'Gerenciar assinaturas';
