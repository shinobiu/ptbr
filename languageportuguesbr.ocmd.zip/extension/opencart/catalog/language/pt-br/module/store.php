<?php
// Heading
$_['heading_title'] = 'Escolha uma loja online';

// Text
$_['text_default']  = 'Padrão';
$_['text_store']    = 'Selecione a loja online que deseja visitar.';
