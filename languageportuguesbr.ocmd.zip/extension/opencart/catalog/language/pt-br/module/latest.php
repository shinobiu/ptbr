<?php
// Heading
$_['heading_title'] = 'Novos Produtos';
