<?php
// Text
$_['text_captcha']  = 'Captcha';

// Entry
$_['entry_captcha'] = 'Digite o código da imagem na caixa abaixo.
';

// Error
$_['error_captcha'] = 'O código de teste inserido não corresponde ao display de imagem!';
