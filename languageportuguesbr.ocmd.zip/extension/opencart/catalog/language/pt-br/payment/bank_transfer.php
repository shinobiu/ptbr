<?php
// Heading
$_['heading_title']    = 'PIX / Transferência bancária';

// Text
$_['text_instruction'] = 'Instruções para transferência bancária';
$_['text_description'] = 'Por favor, transfira o valor total para a seguinte conta bancária:
';
$_['text_payment']     = 'Seu pedido só será entregue após o recebimento do pagamento por nós.';
