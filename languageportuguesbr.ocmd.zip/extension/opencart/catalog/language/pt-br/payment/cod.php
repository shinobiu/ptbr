<?php
// Heading
$_['heading_title']        = 'Pagamento na entrega';

// Error
$_['error_order_id']       = 'Sem ordem, não. na sessão!';
$_['error_payment_method'] = 'O método de pagamento não está correto!';
