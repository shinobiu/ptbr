<?php
// Heading
$_['heading_title']    = 'Pagamento em Dinheiro na Entrega';

// Text
$_['text_instruction'] = 'Instruções para verificação / ordem de dinheiro';
$_['text_payable']     = 'A pagar para: ';
$_['text_address']     = 'Enviar para: ';
$_['text_payment']     = 'Seu pedido só será entregue após o recebimento do pagamento por nós.';
