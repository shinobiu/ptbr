<?php
// Heading
$_['heading_title']    = 'Valor de envio de taxa fixa';

// Text
$_['text_description'] = 'Taxa fixa de envio';
