<?php
// Heading
$_['heading_title']    = 'Coleta';

// Text
$_['text_description'] = 'Coleta';
