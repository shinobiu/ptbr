<?php
// Heading
$_['heading_title']    = 'Envio por unidade (envio de peças)';

// Text
$_['text_description'] = 'Envio por unidade';
