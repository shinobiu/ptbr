<?php
// Heading
$_['heading_title']    = 'Frete grátis';

// Text
$_['text_description'] = 'Frete grátis';
