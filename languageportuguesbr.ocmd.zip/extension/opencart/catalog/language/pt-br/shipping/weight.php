<?php
// Heading
$_['heading_title'] = 'Custos de envio por peso';

// Text
$_['text_weight']   = 'Peso:';
