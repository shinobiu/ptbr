<?php
// Heading
$_['heading_title']        = 'Estimativa de frete';

// Text
$_['text_shipping_method'] = 'Métodos de envio';
$_['text_destination']     = 'Digite um destino para uma estimativa de transporte e impostos.';
$_['text_estimate']        = 'Selecione o método de envio desejado para este pedido.';
$_['text_success']         = 'Sucesso: Sua estimativa para transporte e impostos foi aceita!';

// Entry
$_['entry_country']        = 'País';
$_['entry_zone']           = 'Estado';
$_['entry_postcode']       = 'Cep';

// Error
$_['error_postcode']       = 'O código postal deve ter entre 2 e 10 caracteres de comprimento!';
$_['error_country']        = 'Por favor, selecione um país!';
$_['error_zone']           = 'Por favor, selecione uma região/estado!';
$_['error_shipping']       = 'Atenção! Método de envio necessário!';
$_['error_no_shipping']    = 'Aviso: Atualmente, não há métodos de envio disponíveis. <a href="%s">Por favor, entre em contato conosco</a> para obter mais ajuda!';
