<?php
// Heading
$_['heading_title'] = 'Use um código de cupom de desconto';

// Text
$_['text_coupon']   = 'Cupon (%s)';
$_['text_success']  = 'Sucesso: Seu código de cupom (cupom de desconto) foi aplicado!';
$_['text_remove']   = 'Sucesso: Seu código de cupom (cupom de desconto) foi removido!';

// Entry
$_['entry_coupon']  = 'Digite seu código de cupom (voucher de desconto) aqui';

// Error
$_['error_coupon']  = 'Aviso: O código do cupom (cupom de desconto) é inválido, expirado ou atingiu seu limite de uso!';
$_['error_status']  = 'Aviso! Atenção! Cupons (voucher de desconto) não são ativados nesta loja!';
