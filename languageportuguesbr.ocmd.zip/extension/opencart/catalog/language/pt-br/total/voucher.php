<?php
// Heading
$_['heading_title'] = 'Usar vale presente';

// Text
$_['text_voucher']  = 'Vale Presente (%s)';
$_['text_success']  = 'Sucesso: Seu vale presente foi aplicado!';
$_['text_remove']   = 'Sucesso: Seu vale presente foi removido!';

// Entry
$_['entry_voucher'] = 'Digite seu código de vale presente aqui';

// Error
$_['error_voucher'] = 'Aviso: O vale presente é inválido ou o crédito já foi usado!';
$_['error_status']  = 'Atenção! Vales-presente não são ativados nesta loja!';
