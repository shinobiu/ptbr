<?php
// Text
$_['text_credit']   = 'Crédito da Loja Online (Loja)';
$_['text_order_id'] = 'Ordem Nº: #%s';
