<?php
// Heading
$_['heading_title'] = 'Pagar com pontos de recompensa (status de ponto atual %s)';

// Text
$_['text_reward']   = 'Pontos de recompensa (%s)';
$_['text_order_id'] = 'Ordem Nº.: #%s';
$_['text_success']  = 'Sucesso: Seus pontos de recompensa foram aplicados!';
$_['text_remove']   = 'Sucesso: Seus pontos de recompensa foram removidos!';

// Entry
$_['entry_reward']  = 'Pontos utilizáveis (Max %s)';

// Error
$_['error_reward']  = 'Aviso: Digite o número de Pontos de Recompensa para usar!';
$_['error_points']  = 'Aviso: Você não tem pontos de recompensa %s disponíveis!
';
$_['error_maximum'] = 'Atenção: O número máximo de pontos que podem ser usados é %s!';
$_['error_status']  = 'Aviso! Atenção! Os pontos de recompensa não são ativados nesta loja!';
