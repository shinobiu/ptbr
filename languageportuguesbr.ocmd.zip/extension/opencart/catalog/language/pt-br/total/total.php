<?php
// Text
$_['text_total'] = 'Valor total';
