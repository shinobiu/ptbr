<?php
// Text
$_['text_subject']      = '%s - Pedido nº %s';
$_['text_received']     = 'Você recebeu um novo pedido.';
$_['text_order_id']     = 'Pedido nº:';
$_['text_date_added']   = 'Data do pedido:';
$_['text_order_status'] = 'Situação do pedido:';
$_['text_product']      = 'Produtos:';
$_['text_total']        = 'Total:';
$_['text_comment']      = 'O comentário para o seu pedido é:';
