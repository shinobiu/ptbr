<?php
// Text
$_['text_subject']  = '%s - Novo comentário';
$_['text_waiting']  = 'Um novo comentário foi cadastrado e está aguardando aprovação.';
$_['text_product']  = 'Produtos:';
$_['text_reviewer'] = 'Autor: ';
$_['text_rating']   = 'Avaliação:';
$_['text_review']   = 'Comentário:';