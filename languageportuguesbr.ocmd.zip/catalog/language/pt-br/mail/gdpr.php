<?php
// Text
$_['text_subject']  = '%s - Solicitação de exportação/exclusão do GDPR!
';
$_['text_export']   = 'Solicitação de dados de exportação';
$_['text_remove']   = 'Solicitação de exclusão de contas';
$_['text_gdpr']     = 'Uma solicitação do GDPR a partir deste endereço de e-mail, para confirmar esta ação clique no link abaixo:';
$_['text_ip']       = 'O IP usado para fazer esta solicitação foi:';
$_['text_contact']  = 'Se você não fez essa solicitação, entre em contato com o proprietário da loja aqui:';
$_['text_thanks']   = 'Obrigado,';
$_['text_ignore']   = 'Se você não fez essa solicitação, então, por favor, ignore este e-mail.';

// Button
$_['button_export'] = 'Eu confirmo exportar meus dados';
$_['button_remove'] = 'Eu confirmo apagar minha conta';