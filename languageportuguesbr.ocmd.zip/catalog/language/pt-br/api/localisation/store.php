<?php
// Text
$_['text_success'] = 'Sucesso: A loja foi alterada!';

// Error
$_['error_store']  = 'Aviso: A loja não foi encontrada!';