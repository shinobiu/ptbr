<?php
// Text
$_['text_success']   = 'Sucesso: Sua moeda foi alterada!';

// Error
$_['error_currency'] = 'Aviso: A moeda não foi encontrada!';