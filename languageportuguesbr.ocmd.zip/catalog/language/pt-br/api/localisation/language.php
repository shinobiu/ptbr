<?php
// Text
$_['text_success']   = 'Sucesso: Sua linguagem foi alterada!';

// Error
$_['error_language'] = 'Aviso: A linguagem não foi encontrada!';