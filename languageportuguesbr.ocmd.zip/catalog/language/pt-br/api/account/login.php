<?php
// Text
$_['text_success']     = 'Sucesso: A sessão de API começou com sucesso!';

// Error
$_['error_permission'] = 'Aviso: Você não tem permissão para acessar a API!';
$_['error_key']        = 'Aviso: Chave de API incorreta!';
$_['error_ip']         = 'Atenção: Seu IP %s não tem permissão para acessar esta API!';