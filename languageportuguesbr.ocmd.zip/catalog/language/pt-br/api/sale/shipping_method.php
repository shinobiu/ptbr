<?php
// Text
$_['text_success']           = 'Sucesso: O método de envio foi definido!';

// Error
$_['error_shipping_address'] = 'Aviso: Endereço de envio necessário!';
$_['error_shipping_method']  = 'Atenção: Método de envio necessário!';
$_['error_no_shipping']      = 'Atenção: Não há opções de envio disponíveis!';
$_['error_shipping']         = 'Aviso: Não há produtos que exijam o transporte';