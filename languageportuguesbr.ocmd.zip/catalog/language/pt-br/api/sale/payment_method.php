<?php
// Text
$_['text_success']          = 'Sucesso: O método de pagamento foi definido!';

// Error
$_['error_payment_address'] = 'Atenção: Endereço de pagamento necessário!';
$_['error_payment_method']  = 'Atenção: Método de pagamento necessário!';
$_['error_no_payment']      = 'Atenção: Não há opções de pagamento disponíveis!';
$_['error_product']         = 'Atenção: Produtos necessários!';