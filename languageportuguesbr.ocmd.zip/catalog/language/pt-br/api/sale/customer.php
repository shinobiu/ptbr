<?php
// Text
$_['text_success']         = 'Você modificou clientes com sucesso';

// Error
$_['error_customer']       = 'Aviso: O cliente não foi encontrado!';
$_['error_customer_group'] = 'O Grupo de clientes não parece ser válido!';
$_['error_firstname']      = 'O primeiro nome deve ter entre 1 e 32 caracteres!';
$_['error_lastname']       = 'Sobrenome deve ter entre 1 e 32 caracteres!';
$_['error_email']          = 'O endereço de e-mail não parece ser válido!';
$_['error_telephone']      = 'O telefone deve ter entre 3 e 32 caracteres!';
$_['error_custom_field']   = '%s necessário!';
$_['error_regex']          = '%s não é uma entrada válida!';
