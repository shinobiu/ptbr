<?php
// Text
$_['text_success']           = 'O pedido foi modificado com sucesso.';

// Error
$_['error_order']            = 'Aviso: A ordem não foi encontrada!';
$_['error_customer']         = 'Atenção: Os detalhes do cliente são necessários!';
$_['error_payment_address']  = 'Atenção: Endereço de pagamento necessário!';
$_['error_payment_method']   = 'Atenção: Método de pagamento necessário!';
$_['error_no_payment']       = 'Atenção: Não há opções de pagamento disponíveis!';
$_['error_shipping_address'] = 'Aviso: Endereço de envio necessário!';
$_['error_shipping_method']  = 'Atenção: Método de envio necessário!';
$_['error_no_shipping']      = 'Atenção: Não há opções de envio disponíveis!';
$_['error_stock']            = 'Atenção: Produtos marcados com *** não estão disponíveis na quantidade desejada ou não em estoque!';
$_['error_minimum']          = 'Atenção: O valor mínimo do pedido para %s é %s!';
$_['error_product']          = 'Atenção: Produtos necessários!';
$_['error_comment']          = 'Atenção: Comentário necessário!';
