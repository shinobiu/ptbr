<?php
// Text
$_['text_success'] = 'Sucesso: Seu desconto de cupom foi aplicado!';
$_['text_remove']  = 'Sucesso: Seu desconto de cupom foi removido!';

// Error
$_['error_coupon'] = 'Aviso: O cupom é inválido, expirado ou atingido o limite de uso do seu';