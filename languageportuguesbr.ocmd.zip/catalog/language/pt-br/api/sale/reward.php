<?php
// Text
$_['text_success']  = 'Os pontos foram utilizados com sucesso.';
$_['text_remove']   = 'Sucesso: Seu desconto de pontos de recompensa foi removido!';

// Error
$_['error_reward']  = 'Aviso: Digite a quantidade de pontos de recompensa para usar!';
$_['error_points']  = 'Aviso: Você não tem pontos de recompensa %s!';
$_['error_maximum'] = 'Atenção: O número máximo de pontos que podem ser aplicados é %s!';