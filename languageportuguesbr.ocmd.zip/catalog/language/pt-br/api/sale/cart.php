<?php
// Text
$_['text_success']               = 'Sucesso: Você modificou seu carrinho de compras!';
$_['text_subscription']          = 'Subscrição';
$_['text_subscription_trial']    = '%s a todos os %d%s(s) para pagamento%d(s) em seguida';
$_['text_subscription_duration'] = '%s a %d %s(s) para pagamento%d(s)';
$_['text_subscription_cancel']   = '%s a todos os %d%s(s) até que seja cancelado';
$_['text_day']                   = 'dia';
$_['text_week']                  = 'semana';
$_['text_semi_month']            = 'quinzena';
$_['text_month']                 = 'mês';
$_['text_year']                  = 'Ano';
$_['text_for']                   = '%s Vale presente para %s';

// Error
$_['error_stock']                = 'Os produtos marcados com *** não estão disponíveis na quantidade desejada ou não em estoque!';
$_['error_minimum']              = 'O valor mínimo do pedido para %s é %s!';
$_['error_store']                = 'O produto não pode ser comprado na loja que você escolheu!';
$_['error_required']             = '%s necessário!';
$_['error_product']              = 'Aviso: O produto não foi encontrado!';
$_['error_subscription']         = 'Por favor, selecione um plano de assinatura!';