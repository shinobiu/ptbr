<?php
// Text
$_['text_success']    = 'Sucesso: A comissão de afiliados será vinculada a esta ordem!';
$_['text_remove']     = 'Sucesso: Sua comissão de afiliados foi removida!';

// Error
$_['error_affiliate'] = 'Aviso: Afiliado não foi encontrado!';