<?php
// Heading
$_['heading_title'] = 'Sucesso do GDPR';

// Text
$_['text_account']  = 'Conta';
$_['text_export']   = 'Uma solicitação para exportar os dados da sua conta foi recebida.';
$_['text_remove']   = 'As solicitações de exclusão de contas do GDPR serão processadas após <strong>os dias de %s</strong> para que quaisquer chargebacks, reembolsos ou detecção de fraudes possam ser processados.';
