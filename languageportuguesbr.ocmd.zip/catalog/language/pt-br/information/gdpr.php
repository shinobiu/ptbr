<?php
// Heading
$_['heading_title']     = 'Solicitação geral de regulação de proteção de dados';

// Text
$_['text_account']      = 'Conta';
$_['text_gdpr']         = 'Você pode visualizar a política do GDPR %s na página <a href="%s" target="_blank">%s<a/> página.';
$_['text_verification'] = 'Verificação da conta';
$_['text_email']        = 'Antes de podermos realizar qualquer solicitação de GDPR, devemos validá-lo conta. Por favor, digite seu endereço de e-mail abaixo.';
$_['text_action']       = 'Escolha uma ação';
$_['text_export']       = 'Exportar dados pessoais';
$_['text_remove']       = 'Remover dados pessoais';
$_['text_warning']      = 'Aviso: Você perderá o acesso à sua conta!';
$_['text_access']       = 'Você não terá mais acesso à sua conta %s.';
$_['text_history']      = 'Você não terá mais acesso ao seu histórico de pedidos, faturas, listas de desejos ou downloads.';
$_['text_limit']        = 'As solicitações de exclusão da conta serão processadas após <strong>os dias de %s</strong> para que qualquer detecção de fraude, chargebacks ou reembolsos possam ser processados.';
$_['text_success']      = 'Sucesso: Um e-mail foi enviado para o seu endereço de e-mail!';
$_['text_cancel']		= 'Cancelar';

// Entry
$_['entry_email']       = 'E-Mail';

// Error
$_['error_email']       = 'O endereço de e-mail não parece ser válido!';
$_['error_action']      = 'Você deve selecionar uma ação GDPR válida!';
