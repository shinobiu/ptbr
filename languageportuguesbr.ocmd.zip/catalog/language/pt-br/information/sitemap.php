<?php
// Heading
$_['heading_title']    = 'Mapa do site';

// Text
$_['text_special']     = 'Produtos em promoção';
$_['text_account']     = 'Minha conta';
$_['text_edit']        = 'Detalhes da conta';
$_['text_password']    = 'Modificar senha';
$_['text_address']     = 'Endereços';
$_['text_history']     = 'Histórico de pedidos';
$_['text_download']    = 'Downloads';
$_['text_cart']        = 'Carrinho de compras';
$_['text_checkout']    = 'Finalizar pedido';
$_['text_search']      = 'Busca';
$_['text_information'] = 'Informações';
$_['text_contact']     = 'Entre em contato';