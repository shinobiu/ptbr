<?php
// Text
$_['text_error'] = 'Página não encontrada.';