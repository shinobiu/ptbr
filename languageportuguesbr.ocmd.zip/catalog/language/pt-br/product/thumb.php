<?php
// Text
$_['text_price'] = 'Preço:';
$_['text_tax']   = 'Taxas:';