<?php
// Text
$_['text_reviews']    = '%s Comentários';
$_['text_write']      = 'Escreva um Comentário';
$_['text_login']      = 'Escreva um Comentário Por favor <a href="%s">login</a> ou <a href="%s">registr</a> para revisar';
$_['text_no_results'] = 'Não há comentários para este produto.';
$_['text_note']       = '<span class="text-danger">Note:</span> HTML não é traduzido!';
$_['text_success']    = 'Obrigado por sua crítica. Foi submetido para aprovação.';

// Entry
$_['entry_name']       = 'Seu nome';
$_['entry_review']     = 'Sua avaliação';
$_['entry_rating']     = 'Classificação';
$_['entry_good']       = 'Boa';
$_['entry_bad']        = 'Ruim';

// Tabs
$_['tab_review']       = 'Comentários (%s)';

// Error
$_['error_token']      = 'Aviso: Revise token inválido!';
$_['error_product']    = 'Aviso: O produto não foi encontrado!';
$_['error_name']       = 'Nome deve ter entre 3 e 25 caracteres!';
$_['error_text']       = 'Resenha Texto deve ter entre 25 e 1000 caracteres!';
$_['error_rating']     = 'Por favor, selecione uma classificação de revisão!';
$_['error_guest']      = 'Você deve fazer login para revisar o produto!';
$_['error_purchased']  = 'Você deve ter comprado este produto antes de escrever uma revisão!';