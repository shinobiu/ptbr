<?php
// Text
$_['text_success'] = 'Obrigado por nos deixar saber sua escolha!';
$_['text_cookie']  = 'Este site usa cookies. Para obter mais informações <a href="%s" class="alert-link modal-link">click aqui</a>.';

// Button
$_['button_agree']    = 'Sim, tudo bem!';
$_['button_disagree'] = 'Não, obrigado!';