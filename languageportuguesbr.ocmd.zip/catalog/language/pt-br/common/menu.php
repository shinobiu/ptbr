<?php
// Text
$_['text_category']  = 'Categorias';
$_['text_all']       = 'Todas as Categorias';
