<?php
// Text
$_['text_items']                 = '%s item(s) - %s';
$_['text_subscription']          = 'Inscrição';
$_['text_subscription_trial']    = '%s a todos os %d%s(s) para pagamento%d(s) em seguida';
$_['text_subscription_duration'] = '%s a %d %s(s) para pagamento%d(s)';
$_['text_subscription_cancel']   = '%s a todos os %d%s(s) até que seja cancelado';
$_['text_day']                   = 'Dia';
$_['text_week']                  = 'Semana';
$_['text_semi_month']            = 'Quinzenal';
$_['text_month']                 = 'Mês';
$_['text_year']                  = 'Ano';
$_['text_no_results']            = 'Seu carrinho está vazio.';
$_['text_cart']                  = 'Ver Carrinho';
$_['text_checkout']              = 'Finalizar Pedido';