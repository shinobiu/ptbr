<?php
// Heading
$_['heading_title']         = 'Métodos de Pagamento';

// Text
$_['text_account']          = 'Minha Conta';
$_['text_payment_method']   = 'Inscrições do método de pagamento';
$_['text_success']          = 'Seu método de pagamento foi excluído com sucesso';
$_['text_no_results']       = 'Você não tem métodos de pagamento em sua conta.';

// Column
$_['column_payment_method'] = 'Método de Pagamento';
$_['column_type']           = 'Tipo';
$_['column_date_expire']    = 'Data';
$_['column_action']         = 'Ação';

// Error
$_['error_payment_method']  = 'Aviso: O método de pagamento não foi encontrado!';
