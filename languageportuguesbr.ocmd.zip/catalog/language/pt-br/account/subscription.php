<?php
// Heading
$_['heading_title']                        = 'Assinaturas';

// Text
$_['text_account']                         = 'Minha Conta';
$_['text_recurring']                       = 'Informações de pagamento recorrentes';
$_['text_recurring_detail']                = 'Detalhes de pagamento recorrentes';
$_['text_date_added']                      = 'Data adicionada:';
$_['text_status']                          = 'Situação:';
$_['text_payment_method']                  = 'Forma de Pagamento:';
$_['text_order_id']                        = 'Pedido nº:';
$_['text_product']                         = 'Produto:';
$_['text_quantity']                        = 'Quantidade:';
$_['text_description']                     = 'Descrição';
$_['text_reference']                       = 'Referência';
$_['text_transaction']                     = 'TransaÇÕES';
$_['text_status_1']                        = 'AtivO';
$_['text_status_2']                        = 'InactivO';
$_['text_status_3']                        = 'Cancelado';
$_['text_status_4']                        = 'Suspenso';
$_['text_status_5']                        = 'Expirado';
$_['text_status_6']                        = 'Pendente';
$_['text_transaction_date_added']          = 'Criado';
$_['text_transaction_payment']             = 'Pagamento';
$_['text_transaction_outstanding_payment'] = 'Pagamento pendente';
$_['text_transaction_skipped']             = 'Pagamento ignorado';
$_['text_transaction_failed']              = 'Falha no pagamento';
$_['text_transaction_cancelled']           = 'Cancelado';
$_['text_transaction_suspended']           = 'Suspenso';
$_['text_transaction_suspended_failed']    = 'Suspenso o pagamento falhou';
$_['text_transaction_outstanding_failed']  = 'Pagamento pendente falhou';
$_['text_transaction_expired']             = 'Expirado';
$_['text_no_results']                      = 'Não foram encontradas assinaturas!';
$_['text_error']                           = 'A ordem recorrente que você pediu não pôde ser encontrada!';
$_['text_cancelled']                       = 'O pagamento recorrente foi cancelado.';

// Column
$_['column_subscription_id']               = 'Assinatura nº';
$_['column_product']                       = 'ProduTO';
$_['column_status']                        = 'Situação';
$_['column_date_added']                    = 'Data';
$_['column_type']                          = 'Tipo';
$_['column_amount']                        = 'Quantidade';

// Error
$_['error_not_cancelled']                  = 'Erro: %s';
$_['error_not_found']                      = 'Não poderia cancelar recorrente';

// Button
$_['button_return']                        = 'Retornar';
