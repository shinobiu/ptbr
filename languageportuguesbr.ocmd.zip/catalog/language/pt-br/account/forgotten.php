<?php
// Heading
$_['heading_title']      = 'Esqueceu a senha';
$_['heading_reset']      = 'Solicitar nova senha';

// Text
$_['text_account']       = 'Minha conta';
$_['text_forgotten']     = 'Solicitar nova senha';
$_['text_your_email']    = 'Seu e-mail já cadastrado em nossa loja';
$_['text_email']         = 'Digite o e-mail associado à sua conta. Depois pressione o botão <b>Continuar</b> para enviarmos um e-mail para você.';
$_['text_password']      = 'Nova senha';
$_['text_success']       = 'Sucesso: Sua senha foi atualizada com sucesso.';

// Entry
$_['entry_email']        = 'E-Mail';
$_['entry_new_password'] = 'Nova senha';
$_['entry_password']     = 'Repetir a senha';
$_['entry_confirm']      = 'Confirmar';

// Error
$_['error_email']        = 'E-Mail Address does not appear to be valid!';
$_['error_not_found']    = 'Atenção: O e-mail informado não foi localizado em nossa loja, tente novamente';
$_['error_password']     = 'A senha deve ter entre 4 e 20 caracteres.';
$_['error_confirm']      = 'Atenção: A sua conta necessita de aprovação antes que você possa acessá-la.';
$_['error_code']         = 'O código de redefinição de senha é inválido ou foi usado anteriormente!';
