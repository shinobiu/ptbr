<?php
// Heading
$_['heading_title'] = 'Sair';

// Text
$_['text_message']  = '<p>Você foi logado fora de sua conta. Agora é seguro deixar o computador.</p> <p>Seu carrinho de compras foi salvo, os itens dentro dele serão restaurados sempre que você fizer login de volta em sua conta.</p>';
$_['text_account']  = 'Minha Conta';
$_['text_logout']   = 'Sair';