<?php
// Heading
$_['heading_title']      = 'Seus pontos de recompensa';

// Column
$_['column_date_added']  = 'Data';
$_['column_description'] = 'Descrição';
$_['column_points']      = 'Pontos';

// Text
$_['text_account']       = 'Minha Conta';
$_['text_reward']        = 'Pontos de recompensa';
$_['text_total']         = 'Seu número total de pontos de recompensa é:';
$_['text_no_results']    = 'Você não tem nenhum ponto de recompensa!';