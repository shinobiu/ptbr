<?php
// Heading
$_['heading_title']    = 'Informativo de Notícias';

// Text
$_['text_account']     = 'Minha Conta';
$_['text_newsletter']  = 'Informativo';
$_['text_success']     = 'Sucesso: Sua assinatura de newsletter foi atualizada com sucesso!';

// Entry
$_['entry_newsletter'] = 'Inscrever-se';