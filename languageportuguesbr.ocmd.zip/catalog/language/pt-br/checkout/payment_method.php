<?php
// Heading
$_['heading_title']         = 'Formas de Pagamento';

// Text
$_['text_stored']           = 'Métodos de pagamentos';
$_['text_comments']         = 'Adicione comentários sobre seu pedido';
$_['text_agree']            = 'Eu li e concordo com a classe <a href="%s" classe="modal-link"><b>%s</b></a>';
$_['text_success']          = 'Sucesso: Você mudou o método de pagamento!';
$_['text_comment']          = 'Sucesso: Comentário adicionado!';

// Error
$_['error_payment_address'] = 'Atenção: Endereço de pagamento necessário!';
$_['error_payment_method']  = 'Atenção: Método de pagamento necessário!';
$_['error_no_payment']      = 'Aviso: Não há opções de pagamento disponíveis. Por favor, <a href="%s" >constimos</a> ajuda!';