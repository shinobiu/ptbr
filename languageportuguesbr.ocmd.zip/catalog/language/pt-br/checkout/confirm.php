<?php
// Text
$_['text_subscription']          = 'Subscrição';
$_['text_subscription_trial']    = '%s a todos os %d%s(s) para pagamento%d(s) em seguida';
$_['text_subscription_duration'] = '%s a %d %s(s) para pagamento%d(s)';
$_['text_subscription_cancel']   = '%s a todos os %d%s(s) até que seja cancelado';
$_['text_day']                   = 'dia';
$_['text_week']                  = 'semana';
$_['text_semi_month']            = 'quinzenal';
$_['text_month']                 = 'mês';
$_['text_year']                  = 'ano';

// Column
$_['column_name']                = 'Nome do produto';
$_['column_model']               = 'Modelo';
$_['column_quantity']            = 'Quantidade';
$_['column_price']               = 'Preço unitário';
$_['column_total']               = 'Total';