<?php
// Heading
$_['heading_title'] = 'Finalizar pedido';

// Text
$_['text_cart']     = 'Carrinho de compras';