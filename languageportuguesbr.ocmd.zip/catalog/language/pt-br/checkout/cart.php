<?php
// Heading
$_['heading_title']              = 'Carrinho de compras';

// Text
$_['text_success']               = 'Você adicionou <a href="%s">%s</a> ao seu <a href="%s">carrinho de compras</a>.';
$_['text_edit']                  = 'Você modificou seu carrinho de compras.';
$_['text_remove']                = 'Você modificou seu carrinho de compras.';
$_['text_login']                 = 'Atenção: Você necessita <a href="%s">acessar</a> sua conta ou <a href="%s">cadastrar-se</a> para ver os preços.';
$_['text_no_results']            = 'Seu carrinho de compras está vazio.';
$_['text_next']                  = 'O que você deseja?';
$_['text_next_choice']           = 'Clique na opção abaixo:';
$_['text_points']                = 'Pontos:';
$_['text_subscription']          = 'Subscrição';
$_['text_subscription_trial']    = '%s a todos os %d%s(s) para pagamento%d(s) em seguida';
$_['text_subscription_duration'] = '%s a %d %s(s) para pagamento%d(s)';
$_['text_subscription_cancel']   = '%s a todos os %d%s(s) até que seja cancelado';
$_['text_day']                   = 'Dia';
$_['text_week']                  = 'Semana';
$_['text_semi_month']            = 'Quinzenal';
$_['text_month']                 = 'Mês';
$_['text_year']                  = 'Ano';

// Column
$_['column_image']               = 'Imagem';
$_['column_name']                = 'Nome do Produto';
$_['column_model']               = 'Modelo';
$_['column_quantity']            = 'Quantidade';
$_['column_price']               = 'Preço Unitário';
$_['column_total']               = 'Total';

// Error
$_['error_stock']                = 'Os produtos marcados com *** não estão disponíveis na quantidade desejada ou não em estoque!';
$_['error_minimum']              = 'O valor mínimo do pedido para %s é %s!';
$_['error_required']             = 'O campo %s é obrigatório.';
$_['error_product']              = 'Atenção: Não há produtos no seu carrinho de compras.';
$_['error_subscription']         = 'Selecione um plano de assinatura!';
