<?php
// Heading
$_['heading_title']         = 'Endereço de pagamento';

// Text
$_['text_address_new']      = 'Quero usar um novo endereço.';
$_['text_address_existing'] = 'Eu quero usar um endereço existente';
$_['text_success']          = 'Sucesso: Você mudou o endereço de pagamento!';

// Entry
$_['entry_address']         = 'Escolha endereço';
$_['entry_firstname']       = 'Nome';
$_['entry_lastname']        = 'Sobrenome';
$_['entry_company']         = 'Referência';
$_['entry_address_1']       = 'Endereço';
$_['entry_address_2']       = 'Bairro';
$_['entry_postcode']        = 'Cep';
$_['entry_city']            = 'Cidade';
$_['entry_country']         = 'País';
$_['entry_zone']            = 'Estado';

// Error
$_['error_address']         = 'Aviso: O endereço de pagamento não foi encontrado!';
$_['error_firstname']       = 'O primeiro nome deve ter entre 1 e 32 caracteres!';
$_['error_lastname']        = 'Sobrenome deve ter entre 1 e 32 caracteres!';
$_['error_address_1']       = 'O endereço 1 deve ter entre 3 e 128 caracteres!';
$_['error_city']            = 'A cidade deve ter entre 2 e 128 caracteres!';
$_['error_postcode']        = 'O código postal deve ter entre 2 e 10 caracteres!';
$_['error_country']         = 'Por favor, selecione um país!';
$_['error_zone']            = 'Por favor, selecione um estado!';
$_['error_custom_field']    = '%s necessário!';
$_['error_regex']           = '%s não é uma entrada válida!';
