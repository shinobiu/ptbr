<?php
// Heading
$_['heading_title'] = 'Seu pedido foi realizado!';

// Text
$_['text_basket']   = 'Carrinho';
$_['text_checkout'] = 'Finalizar Pedido';
$_['text_success']  = 'Sucesso';
$_['text_customer'] = '<p>Seu pedido foi processado com sucesso!</p> <p>Você pode visualizar seu histórico de pedidos indo à página de conta <a href="%s">minha conta</a> e clicando em <a href="%s" >histórico de Pedidos</a>.</p> <p>Se sua compra tiver um download associado, você pode ir à página <a href="%s">downloads</a> para visualizá-los.</p> <p>Por favor, direcione todas as perguntas que você tem para o proprietário <a href="%s">Loja</a>.</p> <p>Obrigado por fazer compras conosco online!</p>';
$_['text_guest']    = '<p>Seu pedido foi processado com sucesso!</p> <p>Por favor, direcione todas as perguntas que você tem para o proprietário <a href="%s">store</a>.</p> <p>Obrigado por fazer compras conosco online!</p>';