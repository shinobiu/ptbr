<?php
// Heading
$_['heading_title']    = 'Compre um Vale de Presente';

// Text
$_['text_account']     = 'Minha Conta';
$_['text_voucher']     = 'Vale de Presente';
$_['text_description'] = 'Este vale presente será enviado por e-mail para o destinatário depois que seu pedido for pago.';
$_['text_agree']       = 'Eu entendo que os vales-presente não são reembolsáveis';
$_['text_message']     = '<p>Obrigado por comprar um vale presente! Uma vez que você tenha completado seu pedido, seu destinatário do vale-presente receberá um e-mail com detalhes sobre como resgatar seu vale presente.</p>
';
$_['text_for']         = '%s Vale presente para %s';

// Entry
$_['entry_to_name']    = 'Nome do destinatário';
$_['entry_to_email']   = 'E-mail do destinatário';
$_['entry_from_name']  = 'Nome';
$_['entry_from_email'] = 'E-mail';
$_['entry_theme']      = 'Tema do Vale presente';
$_['entry_message']    = 'Mensagem';
$_['entry_amount']     = 'Quantidade';

// Help
$_['help_message']     = 'Opcional';
$_['help_amount']      = 'O valor deve ser entre %s e %s';

// Error
$_['error_token']      = 'Aviso: Token de voucher inválido!';
$_['error_voucher']    = 'O voucher não foi encontrado!';
$_['error_to_name']    = 'O nome do destinatário deve ter entre 1 e 64 caracteres!';
$_['error_from_name']  = 'Seu nome deve ter entre 1 e 64 caracteres!';
$_['error_email']      = 'O endereço de e-mail não parece ser válido!';
$_['error_theme']      = 'Você deve selecionar um tema!
';
$_['error_amount']     = 'O valor deve ser entre %s e %s!';
$_['error_agree']      = 'Aviso: Você deve concordar que os vales-presente não são reembolsáveis!';