<?php
// Heading
$_['heading_title']           = 'Seus dados pessoais';

// Text
$_['text_login']              = 'Se você já tem uma conta conosco, faça login no <a href="%s"><strong>login page</strong></a>.';
$_['text_register']           = 'Cadastrar Conta';
$_['text_guest']              = 'Finalizar como Visitante';
$_['text_payment_address']    = 'Endereço de Pagamento';
$_['text_shipping_address']   = 'Endereço de Envio';
$_['text_your_password']      = 'Senha';
$_['text_agree']              = 'Eu li e concordo com a classe <a href="%s" class="modal-link"><b>%s</b></a>';
$_['text_success_add']        = 'Sucesso: Sua conta foi criada!';
$_['text_success_edit']       = 'Sucesso: Sua conta foi atualizada com sucesso.';

// Entry
$_['entry_customer_group']    = 'Tipo de conta';
$_['entry_firstname']         = 'Nome';
$_['entry_lastname']          = 'Sobrenome';
$_['entry_email']             = 'E-Mail';
$_['entry_telephone']         = 'Telefone';
$_['entry_password']          = 'Senha';
$_['entry_confirm']           = 'Confirmar Senha';
$_['entry_company']           = 'Referência';
$_['entry_address_1']         = 'Endereço';
$_['entry_address_2']         = 'Bairro';
$_['entry_postcode']          = 'Cep';
$_['entry_city']              = 'Cidade';
$_['entry_country']           = 'País';
$_['entry_zone']              = 'Estado';
$_['entry_match']             = 'Meus endereços de entrega e faturamento são os mesmos.';
$_['entry_newsletter']        = 'Quero assinar a newsletter %s.';

// Error
$_['error_guest']             = 'Atenção: Os itens do seu carrinho de compras exigem que você cadastre-se para uma conta!';
$_['error_firstname']         = 'O primeiro nome deve ter entre 1 e 32 caracteres!';
$_['error_lastname']          = 'Sobrenome deve ter entre 1 e 32 caracteres!';
$_['error_customer_group']    = 'O Grupo de Clientes não parece ser válido!';
$_['error_customer_approval'] = 'Aviso: Este grupo de clientes requer aprovação e não pode ser usado com conta de hóspedes.';
$_['error_email']             = 'O endereço de e-mail não parece ser válido!';
$_['error_exists']            = 'Aviso: Endereço de e-mail já está registrado!';
$_['error_telephone']         = 'O telefone deve ter entre 3 e 32 caracteres!';
$_['error_password']          = 'A senha deve ter entre 4 e 20 caracteres!';
$_['error_confirm']           = 'A confirmação da senha não corresponde à senha!';
$_['error_address_1']         = 'O endereço 1 deve ter entre 3 e 128 caracteres!';
$_['error_city']              = 'A cidade deve ter entre 2 e 128 caracteres!';
$_['error_postcode']          = 'O código postal deve ter entre 2 e 10 caracteres!';
$_['error_country']           = 'Por favor, selecione um país!';
$_['error_zone']              = 'Por favor, selecione uma região/estado!';
$_['error_agree']             = 'Aviso: Você deve concordar com os %s!';
$_['error_custom_field']      = '%s Obrigatório!';
$_['error_regex']             = '%s não é uma entrada válida!';
