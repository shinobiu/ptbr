<?php
// Heading
$_['heading_title']          = 'Formas de Envio';

// Text
$_['text_success']           = 'Sucesso: Você mudou o método de envio!';

// Error
$_['error_shipping_address'] = 'Aviso: Endereço de envio necessário!';
$_['error_shipping_method']  = 'Atenção: Método de envio necessário!';
$_['error_no_shipping']      = 'Aviso: Não há opções de envio disponíveis. Por favor, <a href="%s" >constimos</a> ajuda!';
