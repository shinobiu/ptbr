<?php
// Text
$_['text_subject']  = '%s - Reward Points';
$_['text_received'] = 'You have received %s Reward Points!';
$_['text_total']    = 'Your total number of reward points is now %s.';